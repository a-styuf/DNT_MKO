#ifndef _TYPES_H_
#define _TYPES_H_

#define uint8 unsigned char
#define int8 signed char
#define uint16 unsigned int
#define int16 signed int
#define uint32 unsigned long
#define int32 long


#endif

