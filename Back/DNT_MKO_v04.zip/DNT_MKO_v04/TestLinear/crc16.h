#ifndef _CRC16_H_
#define _CRC16_H_

uint16 crc16_ccitt(uint8 *buf, uint8 len);

#endif /* _CRC16_H_ */